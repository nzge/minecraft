# .
 minceraft


This map is too large to host directly on CurseForge.

Please download it from:
https://yourlink.com (Google Drive, Dropbox, etc.)
